export const Users = [
    {
      "id": 1,
      "first_name": "Kalyani",
      "last_name": "Padmawar",
      "email": "kalyani@gmail.com",
      "gender": "Female",
    },
    {
      "id": 2,
      "first_name": "Radha",
      "last_name": "Joshi",
      "email": "radha@gmail.com",
      "gender": "Female",
    },
    {
      "id": 3,
      "first_name": "Ram",
      "last_name": "Yadhav",
      "email": "ram23@gmail.com",
      "gender": "Male",
    },
    {
      "id": 4,
      "first_name": "Jenisha",
      "last_name": "Pawar",
      "email": "jenisha@gmail.com",
      "gender": "Female",
    },
    {
        "id": 5,
        "first_name": "Jenisha",
        "last_name": "Pawar",
        "email": "jenisha@gmail.com",
        "gender": "Female",
      }]