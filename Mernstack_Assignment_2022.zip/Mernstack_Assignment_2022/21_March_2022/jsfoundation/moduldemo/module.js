// global to module.js
// var i = 10;
// Immediately Invocable Function Expression 
(function (){
    var i = 10;
    console.log("In The IIFE i = " + i);
    alert("Call ");
})();