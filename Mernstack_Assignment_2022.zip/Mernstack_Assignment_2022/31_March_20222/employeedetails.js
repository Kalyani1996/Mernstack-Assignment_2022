const bookList = [{name: "Harry Potter", Department: "IT", release_date: "2010-11-20"},
                  {name: "Da Vinci Code", Department: "IT", release_date: "1990-03-04"},
                  {name: "Breaking Dawn", Department: "Bank", release_date: "2001-08-14"},
                  {name: "Eclipse", Department: "Bank", release_date: "2006-05-22"}]

                  const b = bookList.reduce((result, item) => {
                    if (item.Department == 'IT') { result = item }
                    return result
                  }, null)

                  console.log("b--------------",b);


                //   const bookMinPage = bookList.reduce(

                //     (min, item) => {
                    
                //       return min.no_pages > item.no_pages ? item : min
                    
                //     }, bookList[0]);
                    
                //     console.log(bookMinPage) 
                    
                //     //{name: "Breaking Dawn", no_pages: 600, release_date: "2001-08-14"}
                    
                //     // Finding object with minimum no_pages value
                    
                //     const bookMaxPage = bookList.reduce(
                    
                //     (min, item) => {
                    
                //       return min.no_pages < item.no_pages ? item : min
                    
                //     }, bookList[0]);
                    
                //     console.log(bookMaxPage)
                    
                //     //{name: "Eclipse", no_pages: 1200, release_date: "2006-05-22"}
                