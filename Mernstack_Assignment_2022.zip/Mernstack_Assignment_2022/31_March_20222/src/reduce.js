window.onload = function () {
    Products = [
              {ProductId:21,ProductName:'Mobile',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:22,ProductName:'Desktop',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'},

        {ProductId:23,ProductName:'Laptop',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:24,ProductName:'Mouse',CategoryName:'Android', Price:'5000', Manufacturer:'Samsung'},

        {ProductId:25,ProductName:'CPU',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'},

        {ProductId:26,ProductName:'Cable',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:27,ProductName:'Charger',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:28,ProductName:'Powerbank',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'},

        {ProductId:29,ProductName:'Keyboard',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:30,ProductName:'Pen',CategoryName:'Android', Price:'5000', Manufacturer:'Samsung'},

        {ProductId:31,ProductName:'Mobile',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'},

        {ProductId:32,ProductName:'A',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:33,ProductName:'D',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'},

        {ProductId:34,ProductName:'D',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:35,ProductName:'D',CategoryName:'Android', Price:'5000', Manufacturer:'Samsung'},

        {ProductId:36,ProductName:'A',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'},

        {ProductId:37,ProductName:'A',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:38,ProductName:'C',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:39,ProductName:'C',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'},

        {ProductId:40,ProductName:'C',CategoryName:'Android', Price:'5000', Manufacturer:'Samsung'},

        {ProductId:41,ProductName:'A',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:42,ProductName:'A',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'},

        {ProductId:43,ProductName:'A',CategoryName:'Android', Price:'5000', Manufacturer:'Samsung'},

        {ProductId:44,ProductName:'A',CategoryName:'D1', Price:'500', Manufacturer:'Nokia'},

        {ProductId:45,ProductName:'D',CategoryName:'Android', Price:'5000', Manufacturer:'Samsung'},

        {ProductId:46,ProductName:'D',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'},

        {ProductId:47,ProductName:'D',CategoryName:'Android', Price:'5000', Manufacturer:'Samsung'},

        {ProductId:48,ProductName:'A',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'},

        {ProductId:49,ProductName:'D',CategoryName:'Android', Price:'5000', Manufacturer:'Samsung'},

        {ProductId:50,ProductName:'C',CategoryName:'IOS', Price:'500', Manufacturer:'Apple'}

    

    ];
    var tbody = document.getElementById("tbdy");
    for (var index = 0; index < Products.length; index++) {
        tbody.innerHTML += "<tr class='table-primary'><td>" + Products[index].ProductId + "</td><td>" + Products[index].ProductName + "</td><td>" + Products[index].CategoryName + "</td><td>" + Products[index].Price + "</td><td>" + Products[index].Manufacturer + "</td></tr>";
    }

    // for (let value of Object.values(arr)) {
    //     alert(value);
    // }
    var manId = document.getElementById("manId");
    manId.addEventListener('click', function () {
        Objectt = crateProductGroup(Products, 'Manufacturer');
        Products = [];
        for (let value of Object.values(Objectt)) {
            // alert(value);
            for (let product of value) {
                Products.push(product);
            }
        }
        // console.log(Products);
        var tbody = document.getElementById("tbdy");
        tbody.innerHTML = "";
        for (var index = 0; index < Products.length; index++) {
            tbody.innerHTML += "<tr class='table-primary'><td>" + Products[index].ProductId + "</td><td>" + Products[index].ProductName + "</td><td>" + Products[index].CategoryName + "</td><td>" + Products[index].Price + "</td><td>" + Products[index].Manufacturer + "</td></tr>";
        }

    }, false);

    var catId = document.getElementById("catId");
    catId.addEventListener('click', function () {
        Objectt = crateProductGroup(Products, 'CategoryName');
        Products = [];
        for (let value of Object.values(Objectt)) {
            // alert(value);
            for (let product of value) {
                Products.push(product);
            }
        }
        // console.log(Products);
        var tbody = document.getElementById("tbdy");
        tbody.innerHTML = "";
        for (var index = 0; index < Products.length; index++) {
            tbody.innerHTML += "<tr class='table-primary'><td>" + Products[index].ProductId + "</td><td>" + Products[index].ProductName + "</td><td>" + Products[index].CategoryName + "</td><td>" + Products[index].Price + "</td><td>" + Products[index].Manufacturer + "</td></tr>";
        }

    }, false);

    var searchBar = document.getElementById("searchBar");
    searchBar.addEventListener('change', function () {
        var searchText = searchBar.value;
        tbody.innerHTML = " ";
        if (searchText == "") {
            for (var index = 0; index < Products.length; index++) {
                tbody.innerHTML += "<tr class='table-primary'><td>" + Products[index].ProductId + "</td><td>" + Products[index].ProductName + "</td><td>" + Products[index].CategoryName + "</td><td>" + Products[index].Price + "</td><td>" + Products[index].Manufacturer + "</td></tr>";
            }
            console.log(tbody)
        } else {
            let obj = Products.find(o => o.ProductName === searchText);
            tbody.innerHTML = "<tr class='table-primary'><td>" + obj.ProductId + "</td><td>" + obj.ProductName + "</td><td>" + obj.CategoryName + "</td><td>" + obj.Price + "</td><td>" + obj.Manufacturer + "</td></tr>";
            console.log(tbody)
        }
    }, false);
}



function crateProductGroup(records, property) {
    // groupResult: Initial State {}
    // record: The current record to be read
    Products = [];
    let result = records.reduce((groupResult, record) => {
        console.log(`Current State ${JSON.stringify(groupResult)} and current record ${JSON.stringify(record)}`);
        // read the key on which the group will be created on the current record
        let key = record[property]; // currentRecord[dname] this will be value of the property for the record
        // key will be D1, D2, D3
        console.log(`Key of the record = ${key}`);

        // match each record with the previous record key in the groupResult state
        // because groupResult has the resultant records
        if (!groupResult[key]) {
            groupResult[key] = []; // if the match does not found based on key makes the resultant as empty
        }
        // if found then add the matched record in the resultant state
        groupResult[key].push(record);
        console.log(`After match found for push state is = ${JSON.stringify(groupResult)}`);
        // return the final group state
        console.log("+++++++++++++++++++++++++++++++++++");
        return groupResult;

    }, {});

    return result;
};
