for(var j=0;j<=10;j++){
    console.log("using j loop");

}
console.log("out of j loop" +j);

console.log("using let");
for(let i=0;i<=10;i++){
    console.log("using i loop");

    
}
console.log("out of i loop" + i);
