//babel .\source\Assignment31stMarch.js -o .\transpile\Assignment31stMarch.build.js

let Departments = ['Account','IT','Sales']
let Employees = [
    {EmpNo:101,EmpName:'Rohan',DeptName:'Account',Designation:'Clerk'},
    {EmpNo:102,EmpName:'Akshata',DeptName:'IT',Designation:'Manager'},
    {EmpNo:103,EmpName:'John',DeptName:'Sales',Designation:'Operator'},
    {EmpNo:104,EmpName:'Monika',DeptName:'Sales',Designation:'Operator'},
    {EmpNo:104,EmpName:'Ritik',DeptName:'IT',Designation:'Manager'},
    {EmpNo:106,EmpName:'Monu',DeptName:'Sales',Designation:'Operator'},
    {EmpNo:107,EmpName:'Ritu',DeptName:'Account',Designation:'Clerk'}

] 

let empByDept = {};

  empByDept = Employees.reduce((prevValue,currValue)=>{
     if(currValue.DeptName in prevValue){
        prevValue[currValue.DeptName]++;  
    }else{
        prevValue[currValue.DeptName] = 1; 
    }
    return empByDept;
},{});
console.log(`Number of Employes group by dept no. ${JSON.stringify(empByDept)}`);

let frequency = Employees.reduce((prevValue,currValue)=>{
    if(currValue.Designation in prevValue){
        prevValue[currValue.Designation]++;
    }else{
        prevValue[currValue.Designation] = 1;
    }
    return prevValue;
},{});
console.log(`No. of Managers, Clerk and Operators: ${JSON.stringify(frequency)}`);



let result = Employees.reduce((groupByDept,e)=>{
  let deptName = e.DeptName;
  if(groupByDept[deptName]==null) groupByDept[deptName] = []
   groupByDept[deptName].push(e);
  return groupByDept;
},{});
console.log(`Names of Employees group by Department = ${JSON.stringify(result)}`);