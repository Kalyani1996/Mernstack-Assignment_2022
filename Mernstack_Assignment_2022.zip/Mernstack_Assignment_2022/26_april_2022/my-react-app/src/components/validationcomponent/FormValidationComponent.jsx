import React, {useState} from 'react';
// import SelectComponent from '../reusablecomponents/selectcomponent';
import {DataContext} from './../datacontext.js';
import SelectContextComponent from '../reusablecomponents/selectcontextcomponent';
import Select from 'react-select';

const FormValidationComponent=(props)=>{
    const [emp,setEmp] = useState({EmpNo:0,EmpName:'',Designation:'',Department:'',TechnicalExpertise:'',Salary:''});
    const [isEmpNoValid,checkEmpNo] = useState(true);
    const [isEmpNameValid,checkEmpName] = useState(true);
    const [isFormValid,checkForm] = useState(true);
    const save=()=>{
        setEmp(emp);
    };
    console.log("emp----------------",emp);
    const Designations = ['Director', 'CTO', 'Accountant', 'Project Manager', 'Manager', 'Lead', 'Engineer','Developer','Tester','Cashier'];
    const Departments = ['Dev', 'Test', 'Accounts', 'HR', 'System'];
    const TechnicalExpertise = [{label:'C++',value:1},{label:'C#',value:2},{label:'JAVA',value:3},
    {label:'Python',value:4},{label:'Javascript',value:5},{label:'React',value:6},{label:'Anular',value:7},{label:'Jquery',value:8}];

    const [selectedOption,setSelectedOption] = useState(null);
    // let [employeedetail, setDepartment] = useState({empno:0, empname:'', designation:'',department:'',technicalexpertise:'',salary:0});
    // let [employeedetails, updateDepartments] = useState([]);

    const handleChange=(evt)=>{
        if(evt.target.name === 'EmpNo'){
            setEmp({...emp, EmpNo:parseInt(evt.target.value)});
        }
        if(evt.target.name === 'EmpName'){
            setEmp({...emp, EmpName:evt.target.value});
        }
        if(evt.target.name === 'Designation'){
            setEmp({...emp, Designation:evt.target.value});
        }
        if(evt.target.name === 'Department'){
            setEmp({...emp, Department:evt.target.value});
        }
        if(evt.target.name === 'TechnicalExpertise'){
            setEmp({...emp, TechnicalExpertise:evt.target.value});
        }
        if(evt.target.name === 'Salary'){
            setEmp({...emp, Salary:evt.target.value});
        }

      validateForm(evt.target.name,evt.target.value);
    }

    const handleEvent=(e)=>{
        setSelectedOption(e);

    }

    const validateForm=(name,value)=>{
        if(name === "EmpNo"){
            if(parseInt(value)<0){
                checkEmpNo(false);
                checkForm(false);
            }
            else if(value.length===8){
                alert("must be 8 digit")
             }
            else {
                checkEmpNo(true);
                checkForm(true);
            }
        }

        if(name === "EmpName"){
            if(value.length<2){
                checkEmpName(false);
                checkForm(false);
            }
            else {
                checkEmpName(true);
                checkForm(true);
            }
        }

    };

    // var str= "data"
    // var result = str.charAt(0).toUpperCase()+ str.slice(1);
    // console.log("result",result);
    // const {
    //     register,
    //     handleSubmit,
    //     formState: { errors },
    //     reset,
    //     trigger,
    //   } = useForm();

    // function capitalize(str){
    //     return str.charAt(0).toUpperCase()+str.slice(1);
    //   }
    //   capitalize('gowtham') // Gowtham
    //   capitalize('reactgo') // Reactgo


    // const clear=()=>{
    //     // reset department properties
    //     setDepartment({empno:0, empname:'', designation:'',department:'',technicalexpertise:'',salary:0});
    // }

    
    return (
        <div className='container'>
            <h2>The Form Validations</h2>
            <form name="frmEmp">
                <div className='form-group'>
                    <label>EmpNo</label>
                    <input type="text" className='form-control' name="EmpNo" maxLength="8"
                     value={emp.EmpNo} onChange={handleChange}/>
                     <div className='alert alert-danger' hidden={isEmpNoValid}>
                         EmpNo MUST be +ve integer and must be 8 digit 
                     </div>
                </div>
                <div className='form-group'>
                    <label>EmpName</label>
                    <input type="text" className='form-control'  name="EmpName" 
                    value={emp.EmpName} onChange={handleChange} /> 
                    {/* <input
                type="text"
                className={`form-control ${errors.empname && "invalid"}`}
                {...register("empname", { required: "empname is Required",
                pattern: {
                  value: /^\s*(?:\+?(\d{1,3}))?[-. (]*(\d{3})[-. )]*(\d{3})[-. ]*(\d{4})(?: *x(\d+))?\s*$/,
                  message: "Invalid empname",
                },
               })}
               onKeyUp={() => {
                trigger("phone");
              }}
              />
              {errors.phone && (
                <small className="text-danger">{errors.phone.message}</small>
              )} */}
                     <div className='alert alert-danger' hidden={isEmpNameValid}>
                         EmpName must be minimum 2 characters long and 1st letter must be UpperCase
                     </div>
                  
                </div>
                <div className='form-group'>
                    <label>Designation</label>

                    <DataContext.Provider value={Designations} onChange={handleChange} isMulti>
                <SelectContextComponent></SelectContextComponent>    
          </DataContext.Provider>
                    {/* <SelectComponent dataSource={Designations} valueProperty={employeedetail.Designations}
                   getSelectedValue={(value)=>{setDepartment({...employeedetail, Designations:value})}}></SelectComponent> */}
                </div>
                <div className='form-group'>
                    <label>Department</label>
                    <DataContext.Provider value={Departments} onChange={handleChange} >
                <SelectContextComponent></SelectContextComponent>    
          </DataContext.Provider>
                    {/* <SelectComponent dataSource={Departments} valueProperty={employeedetail.Departments}
                   getSelectedValue={(value)=>{setDepartment({...employeedetail, Departments:value})}}></SelectComponent> */}
                </div>
                <div className='form-group'>
                    <label>TechnicalExpertise</label>
                    {/* <DataContext.Provider value={TechnicalExpertise} onChange={handleChange}>
                <SelectContextComponent></SelectContextComponent>     
          </DataContext.Provider> */}
          <Select 
          isMulti 
          placeholder="Select option"
          value={selectedOption}
          options={TechnicalExpertise}
          onChange={handleEvent}
          />
          {selectedOption && <div style={{ marginTop: 20, lineHeight: '25px' }}>
        {/* <b>Selected Options</b><br />
        <pre>{JSON.stringify(selectedOption, null, 2)}</pre> */}
      </div>}
      
                    {/* <SelectComponent dataSource={TechnicalExpertise} isMultiSelect={true} valueProperty={employeedetail.TechnicalExpertise}
                   getSelectedValue={(value)=>{setDepartment({...employeedetail, TechnicalExpertise:value})}}></SelectComponent> */}

                   {/* <SelectComponent dataSource={TechnicalExpertise} isMultiSelect={true} name="TechnicalExpertise"
                   onSelect={handleChange} ></SelectComponent> */}
                   
{/* <select className='form-control' onChange={props.onSelect} multiple={props.isMultiSelect} name={props.name} >{props.dataSource.map((record,index)=>(<option key={index} value={record}>{record}</option> ))}</select> */}


                   
                </div>
                <div className='form-group'>
                    <label>Salary</label>
                    <input type="text" className='form-control' name="Salary"
                    value={emp.Salary} onChange={handleChange}/>
                    </div>
                <div className='form-group'>
                   <input type="reset" value="Reset" className='btn btn-warning'/>
                   <input type="submit" value="Save" className='btn btn-success'
                    disabled={!isFormValid}
                    onClick={save}/>
                    {/* <input type="clear" value="Clear" onclick={clear} className='btn btn-success'/> */}
                </div>
            </form>
            <hr/>
            <div className='container'>
               <strong>
                   {JSON.stringify(emp)}
               </strong>

            </div>    
        </div>
    );
};

export default FormValidationComponent;