// Reading file

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

// Synchronous read         FILE-PATH               ENCODING
// let data = fs.readFileSync('./../files/a.txt', {encoding: 'utf8'});

//Not Working: const path1 = path.join(__dirname, './../files/a.txt');

// 1. Read the Server Path
let __fileName = fileURLToPath(import.meta.url);
console.log(`File Name = ${__fileName}`);
// 2. Combine this with the actual Resource Path
let filePath = path.join(__fileName, "./../../New/");
// let filePath2 = path.join(__fileName, "./../../New/subdirectories/new2.txt");


// fs.stat(filePath, function(err, stats) {
//   console.log(filePath);
//   console.log();
//   console.log(stats);
//   console.log();

//   if (stats.isFile()) {
//       console.log('    file');
//   }
//   if (stats.isDirectory()) {
//       console.log('    directory');
//   }
// });

// fs.readdir (filePath, (err, files) => { console.log (files) }) 
// var files = fs.readdirSync (filePath)
// console.log("files---------------",files);
// // var res=files[2];
// //  fs.statSync(res).isDirectory();

//     files.forEach(function(filename) {
//       fs.readFile(filePath + filename, 'utf-8', function(err, content) {
    
//         console.log("filename---------------",filename);
//         console.log("content---------------",content)

//       });

      
//     });
    let Files = [];

    function ReadDirectory(Directory) {
      fs.readdirSync(Directory).forEach(File => {
    
        const Absolute = path.join(Directory, File);
        console.log("files------------------------",File);
        if (fs.statSync(Absolute).isDirectory()) 
        return ReadDirectory(Absolute);
  
        else {
          fs.readFile(Absolute, { encoding: "utf8" }, (error, fileContent) => {
              if (error) {
              console.log(`Some Error Occurred ${error.message}`);
              return;
            }
              console.log(`Async Data Read Data = ${fileContent}`);
          });
          Files.push(Absolute);
        }
    
      });
    }
    ReadDirectory("C:/Mernstack_training_14_March_2022/nodejs/New");
// console.log('done');
// console.log(`File Path = ${filePath}`);

//read csv

// import XLSX from 'xlsx';
// var workbook = XLSX.readFile('C:/Users/huma.khan/Downloads/file_example_XLS_10.xls');
// var sheet_name_list = workbook.SheetNames;
// var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
// console.log(xlData);












