import express from 'express'
import  multer from 'multer'
import  AWS from 'aws-sdk'
import { v4 as uuid } from 'uuid';

const app = express()
const port = 8000

const s3 = new AWS.S3({
    accessKeyId: '',
    secretAccessKey: ''
})

const storage = multer.memoryStorage({
    destination: function(req, file, callback) {
        callback(null, '')
    }
})

const upload = multer({storage}).single('image')

app.post('/upload',upload,(req, res) => {


    console.log("data----------------",(req.file).toString());

    res.send({
        message:"Hello world"
    })
    
    let myFile = req.file.originalname.split(".")
    const fileType = myFile[myFile.length - 1]
console.log("filetype---------",fileType);
    const params = {
        Bucket: 'imagestestd',
        Key: `${uuid()}.${fileType}`,
        Body: req.file.buffer
    }

    s3.upload(params, (error, data) => {
        if(error){
            res.status(500).send(error)
        }

        res.status(200).send(data)
    })
})

app.listen(port, () => {
    console.log(`Server is up at ${port}`)
})