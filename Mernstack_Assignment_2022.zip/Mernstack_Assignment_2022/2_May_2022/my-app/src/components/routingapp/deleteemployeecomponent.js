import react,{useState, Fragment, useEffect} from 'react'; 
// import hooks to read the parameters from the Route Link and navigate after saving the data
import {useParams, useNavigate} from 'react-router-dom';
import {Link} from 'react-router-dom';
import EmployeeService from '../../services/employeeservice';
// import the select component
import SelectComponent from '../reusablecomponents/selectcomponent';


const DeleteEmployeeComponent=(props)=>{

    let [department, setDepartment] = useState({empno:0, empname:'', department:'',salary:0});
    
    const locations = ['Pune', 'Mumbai', 'Kolhapur', 'Nagpur', 'Nashik', 'Satara', 'Thane'];
    // const locations  =undefined;
    const capacities = [5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100];
    const serv = new EmployeeService();
    const [message, setMessage] = useState("");

    // define navigate and params object
    const navigate = useNavigate();
    const params = useParams();
    const id = parseInt(params.empno);

    // use useEffect() to load the department data for edit purpose  
    useEffect(()=>{
        async function deleteData(){
            try {
                let response = await serv.deleteData(id);
                console.log("rspone-------------------",response);
                setDepartment(response.data.data);

            }catch(ex){
                setMessage(`Error Occurred in Loading data ${ex.message}`);
            }
        }
        deleteData();
    },[]);

   

    return(
        <Fragment>
           
           <Link to={`/list`}></Link>
           
        </Fragment>
    );
};

export default DeleteEmployeeComponent;