import react,{useState, Fragment} from 'react';
import {useNavigate} from 'react-router-dom';

import EmployeeService from '../../services/employeeservice';
// import the select component
import SelectComponent from '../reusablecomponents/selectcomponent';
//   const [setorder] = useState("ASC");


const EditEmployeeComponent=(props)=>{

    let [employee, setDepartment] = useState({empno:0, empname:'', department:'',salary:0});
    
    const department = ['Operation', 'IT', 'Manager', 'Clerk', 'Cashier'];
    // const departments  =undefined;
    const salary = [50000,1000000,600000,800000];
    const serv = new EmployeeService();
    const [message, setMessage] = useState("");
    // lets define a navigate object
    const navigate = useNavigate();



    const save= async ()=>{
         try {
            let response = await serv.postData(employee);
            setMessage('Add is Successful');
            // Navigate to the default page
            navigate("/")
         }catch(ex){
             setMessage(ex.message);
         }    
    };
    const clear=()=>{
        // reset department properties
        setDepartment({empno:0, empname:'', department:'',salary:0});
    }

    // const sorting =(department.empno)=>{
    //         setorder("ASC");
    //     }
    
    return(
        <Fragment>
            <h1>{props.message} Employee</h1>
            <div className='form-group'>
                <label>empno</label>
                <input type="text" value={employee.empno}  onChange={(evt)=>setDepartment({...employee, empno:parseInt(evt.target.value)})} className="form-control"/>
            </div>
            <div className='form-group'>
                <label>empname</label>
                <input type="text" value={employee.empname} onChange={(evt)=>setDepartment({...employee, empname:evt.target.value})} className="form-control"/>
            </div>
            <div className='form-group'>
                <label>department</label>
              
                <input type="text" value={employee.department} onChange={(evt)=>setDepartment({...employee, department:evt.target.value})} className="form-control"/>
            </div>
            <div className='form-group'>
                <label>salary</label>
                <input type="text" value={employee.salary} onChange={(evt)=>setDepartment({...employee, salary:evt.target.value})} className="form-control"/>
                    {/* <SelectComponent dataSource={salary} valueProperty={employee.salary}
                     getSelectedValue={(value)=>{setDepartment({...employee, salary:parseInt(value)})}}></SelectComponent> */}
            </div>
            <div className='form-group'>
                <input type="button" className='btn btn-warning' value="Clear"
                 onClick={clear}/>
                <input type="button" className='btn btn-success' value="Save" onClick={save}/>
            </div>
          
           
           
        </Fragment>
    );
};

export default EditEmployeeComponent;