import styles from "./../../styles/Home.module.css";
import Navigator from "./navigator";
// import axios from 'axios';

// component with props object
const AboutComponent = ({ departments }) => {
    console.log("departments----------",departments.data);
  if (departments === undefined || departments.length === 0) {
    return (
      <div className={styles.container}>
        <Navigator></Navigator>
        <h2>The About Component</h2>
      </div>
    );
  } else {
    return (
      <div className={styles.container}>
        <Navigator></Navigator>
        <h2>The About Component</h2>
         <div>
             <strong>
                 Received Data:
                 <br/>
                 {JSON.stringify(departments)}
             </strong>
             {/* <button type="button" value="post" onClick={save}>PUT</button>
             <button type="button" value="post" onClick={save}>POST</button> */}

         </div>
         <button type="button" value="post" onClick={save}>POST</button>
         <button type="button" value="put" onClick={put}>PUT</button>
         <button type="button" value="put" onClick={deletedata}>DELETE</button>
         
      </div>
    );
  }
};

// the following method will be executed during build
export async function getStaticProps() {
  console.log(`Making an AJAX Call`);

  let response = await fetch("http://localhost:7011/api/departments");
  const departments = await response.json();
  console.log(`Received data = ${JSON.stringify(departments)}`);
  return {
    props: {
      departments,
    },
  };
}

const save = async() =>{

    let response = await fetch("http://localhost:7011/api/departments",{

        //adding method type
        method:"POST",
        body:JSON.stringify({"deptno":305,"deptname":"Clerk","address":"Nagpur","capacity":45}),
        headers:{"Content-type":"application/json"}

    })
    const data = await response.json()
    console.log(data)
}

const put = async() =>{

    let response = await fetch("http://localhost:7011/api/departments/303",{

        //adding method type
        method:"PUT",
        body:JSON.stringify({"deptno":305,"deptname":"operation","address":"Nagpur","capacity":45}),
        headers:{"Content-type":"application/json"}

    })
    const data = await response.json()
    console.log(data)
}

const deletedata = async() =>{

    let response = await fetch("http://localhost:7011/api/departments/8007",{

        //adding method type
        method:"DELETE",
        body:"",
        headers:{"Content-type":"application/json"}

    })
    const data = await response.json()
    console.log(data)
}

export default AboutComponent;