import react,{useState, Fragment} from 'react';
const DepartmentComponent=()=>{

    let [department, setDepartment] = useState({deptno:0, deptname:'', location:'',capacity:0});
    let [departments, updateDepartments] = useState([]);
    
    const locations = ['Pune', 'Mumbai', 'Kolhapur', 'Nagpur', 'Nashik', 'Satara', 'Thane'];

    const save=()=>{
        // mutate the departments array with new department object
        updateDepartments([...departments, department]);
    };
    const clear=()=>{
        // reset department properties
        setDepartment({deptno:0, deptname:'', location:'',capacity:0});
    }

    return(
        <Fragment>
            <div className='form-group'>
            <div>
            Java<input onclick={show} type="checkbox" name="java" />
                <input type="checkbox" />
                </div>
                
            </div>
            
        </Fragment>
    );
};

export default DepartmentComponent;