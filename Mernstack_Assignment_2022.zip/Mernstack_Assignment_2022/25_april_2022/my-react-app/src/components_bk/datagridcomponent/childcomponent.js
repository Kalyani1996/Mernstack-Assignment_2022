import react,{useState, Fragment} from 'react';



const ChildComponent=()=>{

    

    return(
        <Fragment>
            
        </Fragment>
    );
};

export default ChildComponent;