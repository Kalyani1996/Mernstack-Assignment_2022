// const express = require('express');
// const app = express();
// const port =  8000
// app.get("/product",(req,res)=>{

//     res.json({

//         ProductId:233433,
//         ProductName:"mobile",
//         CategoryName:"device",
//         Manufcature:"Tata",
//         Price:"4000",
//         Descripton:"Its a device"
//     })

// });

// app.listen(port),()=>{
//     console.log(`listening to port ${port}`);
// }

var express = require('express');
var app = express();
var fs = require('fs');
const cors = require('cors')

var port = process.env.port || 1337;
 
app.use(cors());

let product  = 

[    {ProductId:233213,
        ProductName:"mobile",
        CategoryName:"device",
        Manufcature:"Tata",
        Price:"4000",
        Descripton:"Its a device",
    
    },
    {ProductId:233433,
            ProductName:"mobile",
            CategoryName:"device",
            Manufcature:"Tata",
            Price:"4000",
            Descripton:"Its a device"},
            {ProductId:4444,
                ProductName:"mobile",
                CategoryName:"device",
                Manufcature:"Tata",
                Price:"9000",
                Descripton:"Its a device"},
                {ProductId:5555,
                    ProductName:"Car",
                    CategoryName:"device",
                    Manufcature:"Tata",
                    Price:"700000",
                    Descripton:"Its a device"}];

app.get("/product",function(request,response)
{
    response.json(product);
});

app.post("/Productlist", (req, res) => {
    res.json(product);
});

app.get('/product/:ProductId', (req, res) => {
    // console.log("req---",res);
    // return res.send(product);
    var result = product.find(function(e) {
        return e.ProductId === 233213 ;
        // || e.ProductId === 233433 || e.ProductId === 4444 ||e.ProductId === 5555;
      });
      return res.send(result);
      
    //   console.log(result)
  });
 
app.listen(port, function () {
    var datetime = new Date();
    var message = "Server running on Port:- " + port + "Started at :- " + datetime;
    console.log(message);
});