"use strict";

//babel .\source\Assignment31stMarch.js -o .\transpile\Assignment31stMarch.build.js
var Departments = ['Finance', 'IT', 'Sales'];
var Employees = [{
  EmpNo: 101,
  EmpName: 'Rohan',
  DeptName: 'Finance',
  Designation: 'Clerk'
}, {
  EmpNo: 102,
  EmpName: 'Akshata',
  DeptName: 'IT',
  Designation: 'Manager'
}, {
  EmpNo: 103,
  EmpName: 'John',
  DeptName: 'Sales',
  Designation: 'Operator'
}, {
  EmpNo: 104,
  EmpName: 'Monika',
  DeptName: 'Sales',
  Designation: 'Operator'
}, {
  EmpNo: 104,
  EmpName: 'Ritik',
  DeptName: 'IT',
  Designation: 'Manager'
}, {
  EmpNo: 106,
  EmpName: 'Monu',
  DeptName: 'Sales',
  Designation: 'Operator'
}, {
  EmpNo: 107,
  EmpName: 'Ritu',
  DeptName: 'Finance',
  Designation: 'Clerk'
}];
var empByDept = {};
empByDept = Employees.reduce(function (prevValue, currValue) {
  if (currValue.DeptName in prevValue) {
    prevValue[currValue.DeptName]++;
  } else {
    prevValue[currValue.DeptName] = 1;
  }

  return empByDept;
}, {});
console.log("Number of Employes group by dept no. ".concat(JSON.stringify(empByDept)));
var frequency = Employees.reduce(function (prevValue, currValue) {
  if (currValue.Designation in prevValue) {
    prevValue[currValue.Designation]++;
  } else {
    prevValue[currValue.Designation] = 1;
  }

  return prevValue;
}, {});
console.log("No. of Managers, Clerk and Operators: ".concat(JSON.stringify(frequency)));
var result = Employees.reduce(function (groupByDept, e) {
  var deptName = e.DeptName;
  if (groupByDept[deptName] == null) groupByDept[deptName] = [];
  groupByDept[deptName].push(e);
  return groupByDept;
}, {});
console.log("Names of Employees group by Department = ".concat(JSON.stringify(result)));
