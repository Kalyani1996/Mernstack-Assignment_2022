export const getDepartments=()=>{
    return {
        type: 'GET_DEPARTMENTS'
    };
};

export const addDepartment=(dept)=>{
    console.log('Add Department is dispatched');
    return {
        type:'ADD_DEPARTMENT',
        dept
    };
}
export const loginDepartment=(dept)=>{
    console.log('Login Department is dispatched');
    return {
        type:'LOGIN_DEPARTMENT',
        dept
    };
}

