import React, {useState, Fragment} from 'react';
import {useDispatch} from 'react-redux';
import {logindepartment} from '../actions/actions';
import SelectComponent from '../../reusablecomponents/selectcomponent';
const LoginDepartmentSAGAComponent=()=>{

    let [department, setDepartment] = useState({username:'',password:''});
 
    // console.log("department--------------------",department);
    // const locations  =undefined;
    // const capacities = [5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100];
    
    const [message, setMessage] = useState("");       
    

    // define a dispatch object

    const dispatch = useDispatch();                     


    const save=()=>{
        dispatch(logindepartment(department));        
    };

    const clear=()=>{
        // reset department properties
        setDepartment({username:'',password:''});
    }

    return(
        <Fragment>
            <h1>Login</h1>
            <div className='form-group'>
                <label>Username</label>
                <input type="text" value={department.username} onChange={(evt)=>setDepartment({...department, username:evt.target.value})} className="form-control"/>
            </div>
            <div className='form-group'>
                <label>Password</label>
                <input type="text" value={department.password} onChange={(evt)=>setDepartment({...department, password:evt.target.value})} className="form-control"/>
            </div>
            <div className='form-group'>
                <input type="button" className='btn btn-warning' value="Clear"
                 onClick={clear}/>
                <input type="button" className='btn btn-success' value="Save" onClick={save}/>
            </div>
          
           
           
        </Fragment>
    );
};

export default LoginDepartmentSAGAComponent;