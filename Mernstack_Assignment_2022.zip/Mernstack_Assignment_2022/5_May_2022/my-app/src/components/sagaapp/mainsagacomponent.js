import React from 'react';
import AddDepartmentComponent from './components/adddepartmentsagacomponent';
import ListDepartmentsComponent from './components/listdepartmentssagacomponent';
import LoginDepartmentSAGAComponent from './components/logindepartmentsagacomponent';
const MainReduxSAGAomponent=()=>{
    return (
        <div className='container'>
            <AddDepartmentComponent></AddDepartmentComponent>
            <hr/>
            <ListDepartmentsComponent></ListDepartmentsComponent>
            <hr/>
            <LoginDepartmentSAGAComponent></LoginDepartmentSAGAComponent>
        </div>
    );
};

export default MainReduxSAGAomponent;