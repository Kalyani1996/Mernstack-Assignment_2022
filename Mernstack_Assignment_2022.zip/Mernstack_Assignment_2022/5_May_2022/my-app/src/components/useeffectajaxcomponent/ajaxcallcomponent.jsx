import React, {useEffect, useState} from 'react';
import DepartmentService from '../../services/departmentservice';

const AjaxCallComponent=()=>{

    const [records, setRecords] = useState([]);
    const [message, setMessage] = useState('');
    const serv = new DepartmentService();

    useEffect(()=>{
        serv.getData().then((response)=>{
            setRecords(response.data.data);
        }).catch((error)=>{
            setMessage(`Error Occurred ${error}`);
        });
    },[]); // any state property that will be modified  (aka make sure that when the state is updated, uswEffect will stop)

    const save=()=>{
        const dept = {
            deptno:8010, deptname:'dept_8010', address: 'area_8010', capacity:78690
        };
        serv.postData(dept).then((response)=>{
            console.log("post response",response.data.data.deptno);

            setRecords([...records, response.data.data]);
        }).catch((error)=>{
            setMessage(`Error Occurred ${error}`);
        });
    };
    const put=()=>{
        const dept = {
            deptno:8010, deptname:'dept_8011', address: 'area_8011', capacity:78690
        };
        serv.putData(dept).then((response)=>{
            console.log("post response",response.data.data.deptno);

            setRecords([...records, response.data.data]);
        }).catch((error)=>{
            setMessage(`Error Occurred ${error}`);
        });
    };

    const deletedata = ()=>{
        // let id = parseInt(records.deptno);
        
        serv.deleteData().then((response)=>{
            setRecords(response.data.data);

        }).catch((error)=>{
            setMessage(`Error Occurred ${error}`);
        });
        
    }


    return(
        <div className='container'>
            <button className='btn btn-primary'>Get Data</button>
            <hr/>
            <button className='btn btn-success' onClick={save}>POST Data</button>
            <hr/>
            <button className='btn btn-success' onClick={put}>PUT Data</button>
            <hr/>
            <button className='btn btn-success' onClick={deletedata}>Delete Data</button>
            <hr/>
            <div className='container'>
                {message}
            </div>
            <hr/>
            <div className='container'>
                {JSON.stringify(records)}
            </div>
        </div>
    );
};

export default AjaxCallComponent;